<?php
function enqueue_parent_and_child_styles() {
    // Enqueue parent theme stylesheet
    wp_enqueue_style('parent-style', get_template_directory_uri() . '/twentytwentytwo-child/style.css');

    // Enqueue child theme stylesheet
    wp_enqueue_style('child-style', get_stylesheet_directory_uri() . '/style.css', array('parent-style'));
    wp_enqueue_style('test-css', get_stylesheet_directory_uri() . "/test.css");
}
add_action('wp_enqueue_scripts', 'enqueue_parent_and_child_styles');

function enqueue_custom_styles() {
    wp_enqueue_style('custom-styles', get_template_directory_uri() . '/style.css');
}
add_action('wp_enqueue_scripts', 'enqueue_custom_styles');

function redirect_non_logged_in_users_to_login() {
    if ( ! is_user_logged_in() && ! is_page('login') ) {
        wp_redirect( wp_login_url() );
        exit();
    }
}
add_action( 'template_redirect', 'redirect_non_logged_in_users_to_login' );
function hr_management_page() {
    // Check if the user is logged in
    if (!is_user_logged_in()) {
        // Redirect to the login page if the user is not logged in
        wp_redirect(wp_login_url());
        exit;
    }

    // Get the current user's information
    $current_user = wp_get_current_user();
    $user_display_name = $current_user->display_name;


    ?>
    <div class="wrap">
        <h1>HR Dashboard</h1>

        <div class="hr-dashboard-container" style="display: flex; justify-content: space-around;">

            <!-- HR Dashboard Section 1 -->
            <div class="hr-dashboard-section">
            <a href="?page=hr_management_page&action=review_cvs">
    <img src="<?php echo plugins_url('/assets/img/profile.png', __FILE__); ?>" width="70" height="52" alt="Icon 1">
</a>
                <h2><?php echo esc_html($user_display_name); ?></h2>
                <p>Helping Hand for HRs</p>
            </div>
            <div class="hr-dashboard-section">
            <a href="?page=hr_management_page&action=review_cvs">
                <img src="<?php echo plugins_url('/assets/img/documents.png', __FILE__); ?>" width="70" height="52" alt="Icon 1">
            </a>
                <h2>Received CVs</h2>
                <h2><?php
                global $wpdb;
                $table_name = $wpdb->prefix . 'resumes';
                
                $query = $wpdb->prepare("SELECT COUNT(*) FROM $table_name");
                $total_rows = $wpdb->get_var($query);
                
                echo $total_rows;
                ?></h2>
            </div>
           
            <div class="hr-dashboard-section">
            <a href="?page=hr_management_page&action=review_cvs">
                <img src="<?php echo plugins_url('/assets/img/documents.png', __FILE__); ?>" width="70" height="52" alt="Icon 1">
            </a>
                <h2>Shortlisted Candidates</h2>
                <h2><?php
                global $wpdb;
                $table_sl = $wpdb->prefix . 'shortlisted_candidates';
                
                $query = $wpdb->prepare("SELECT COUNT(*) FROM $table_sl");
                $total_rows = $wpdb->get_var($query);
                
                echo $total_rows;
                ?></h2>
            </div>
            <!-- Add more dashboard sections as needed -->
        </div>
    </div>
    <?php
}
function customlogin_redirect( $redirect_to, $request, $user ) {
    // Check if $user is a WP_User object
    if ( is_a( $user, 'WP_User' ) ) {
        // Get the current user's role
        $user_role = $user->roles[0];
 
        // Set the URL to redirect users to based on their role
        if ( $user_role == 'subscriber' ) {
            $redirect_to = '/testing/';
        } 
    } else {
        // Handle WP_Error
        error_log( 'Custom login redirect error: User is not a valid WP_User object' );
        // You can redirect the user to a default location or display an error message
        // $redirect_to = '/default-redirect-location/';
    }

    return $redirect_to;
}
add_filter( 'login_redirect', 'custom_login_redirect', 10, 3 );
?>