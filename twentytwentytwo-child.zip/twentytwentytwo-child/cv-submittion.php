<?php
/* 
Template Name: cvsubmissionportal 
*/
?>

<?php
get_header();

$testing = do_shortcode( '[custom_shortcode]' );
echo $testing;
get_footer();
